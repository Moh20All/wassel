# Wassel

The design system for the agency's internal shipment-tracking PWA: China logs each shipment before dispatch, the agency sees it arrive. Clean iOS-style white UI — gray grouped background, white rounded cards, one blue accent, three status colours.

Built from the product brief: iOS system colours and type as specified, adjusted only where small text failed contrast. Logo, app icons and UI icons live in the Assets groups; light/dark theme rules are in the *Theme* section.

## Name

**Wassel** (واصل) — Darija for *it's arrived / it's on its way*, the one question the app answers for every shipment. Short, easy to say in Arabic, French and English, and reads well under a home-screen icon (6 letters, no truncation).

Alternatives considered: **Wosla** (وصلة, “the delivery”), **Manifest** (the shipping-document term), **Dock** (where things arrive). The name appears only in the manifest (`name: "Wassel"`, `short_name: "Wassel"`), the login screen and the icon label.

## Product in one paragraph

Two fixed accounts, one login screen. **China** gets one screen: a form (client name, phone, type Papers/Parts, 1–3 photos, optional note) and a *Submit* button that clears the form for the next one. **Agency** gets a list of every shipment (newest first, filter All / Pending / Arrived / Done) and a detail screen (photos, tappable phone, WhatsApp, note, *Mark arrived*, *Mark delivered*, delete). Delivered shipments auto-delete after 14 days.

## Content fundamentals

- **Voice:** short, operational, English. Labels are nouns (*Client name*, *Phone number*), actions are verbs (*Submit shipment*, *Mark arrived*). No exclamation marks, no emoji.
- **Statuses are exactly three words:** Pending, Arrived, Delivered. The filter's last segment reads *Done* per the brief and maps to `delivered`; if you prefer one word everywhere, rename the segment to *Delivered* — it fits.
- **Time:** `12 min ago` under an hour, `3h ago` under a day, `Yesterday`, then `3 Nov`. Never full timestamps on cards; the detail screen shows `3 Nov 2026, 14:20`.
- **Phone numbers:** shown as typed by China (`0555 12 34 56`). Only the WhatsApp link normalizes (`0` → `213`).
- **Feedback:** after Submit, a brief toast “Shipment logged” with the `delivered` check, then the cleared form. Errors say what to do: “Add at least one photo.”, “No connection — tap Submit again.”
- **Empty states:** list — “No shipments yet. They appear here as soon as China logs them.”; filtered — “Nothing pending.”

## Visual foundations

- **Surfaces:** every screen sits on `bg-grouped` (#f2f2f7). Content lives on `surface` (white) cards and form groups with `radius-md` (12px). No borders around cards and no card shadows: the gray/white contrast is the depth. Hairlines (`separator`) only between rows inside a group.
- **Colour:** one accent, `accent` (#007aff), for the primary button, selected states and focus. Blue *text* uses `accent-ink` (#0066d6) because #007aff is only 4.0:1 on white. Status colours appear as soft pill + ink text + saturated dot:

| Status | Firestore | Badge fill | Text | Dot |
| --- | --- | --- | --- | --- |
| Pending | `pending` | `pending-soft` | `pending-ink` | `pending` (orange) |
| Arrived | `arrived` | `arrived-soft` | `arrived-ink` | `arrived` (blue) |
| Delivered | `delivered` | `delivered-soft` | `delivered-ink` | `delivered` (green) |

- **Type:** the system font (SF Pro on iPhone, Roboto on Android), iOS text styles: `large-title` 34 for screen titles, `title-2` 22 for the client name on detail, `headline`/`body` 17, `subheadline` 15, `footnote` 13, `caption` 12 for badges. Inputs stay 17px so iOS doesn't zoom.
- **Spacing:** 4px base. Screen gutter `space-4` (16px), card gap `space-2`, group gap `space-5`, detail section gap `space-6`.
- **Radius:** `radius-sm` 8 thumbnails/photo slots, `radius-md` 12 cards/buttons/groups, `radius-lg` 16 login card and sheets, `radius-full` pills.
- **Layout:** mobile-first at 390px; content max `layout-max` (430px) centred on bigger screens. Tap targets ≥ `tap-min` (44px). Main buttons live in a sticky bottom `ActionBar` with safe-area padding.
- **Dark mode:** both themes are defined (iOS dark values). Light is the default; follow `prefers-color-scheme` if you want it for free.
- **Motion:** iOS-like and minimal — 200ms ease-out for press/segment changes, a slide-in for the detail screen. No bouncing.

## Logo

- **Mark:** a white arrow dropping into a tray on an `accent` rounded square — a shipment coming in — with a `pending` orange dot: something is on its way. The mark is the app icon.
- **Wordmark:** “Wassel” in Inter Bold, outlined to paths (no font needed). `wassel-wordmark.svg` is `label` black, `-white` for dark grounds.
- **Lockup:** mark + wordmark, for the login screen (`wassel-lockup.svg` light, `-white` dark). Clear space = the height of the orange dot on every side.
- Don't recolour the mark, don't drop the dot, don't put the wordmark on `accent`.

## Iconography

UI icons are in the **Icons** group (24px grid, 2px stroke, round caps and joins, black ink — recolour with CSS `mask` or by inlining and using `currentColor`). Components also draw the same set inline: chevron, camera, phone, chat, papers, parts, close, plus, check, trash, logout, inbound. In the app use **lucide-react** (`ChevronRight`, `Camera`, `Phone`, `MessageCircle`, `FileText`, `Package`, `X`) at 20px, stroke 2 — same look. Don't use the WhatsApp logo; the green chat glyph + the word *WhatsApp* is enough.

## Screens → components

| Screen | Built from |
| --- | --- |
| Login | `wassel-lockup.svg` centred (160px wide, `space-8` above), FormGroup › TextField ×2 (Email, Password), Button primary *Sign in* |
| China — Log shipment | NavBar large *New shipment* + plain *Log out*; FormGroup *Client* (name, phone); FormGroup *Type* › SegmentedControl Papers/Parts; FormGroup *Photos* › PhotoPicker; FormGroup *Note* › TextField multiline; ActionBar › Button *Submit shipment* (loading while uploading) |
| Agency — Shipments | NavBar large *Shipments* + *Log out*; SegmentedControl filter with counts; ShipmentCard list |
| Agency — Detail | NavBar inline with Back; photo strip (swipeable, tap → full-screen on `scrim`); `title-2` client name + StatusBadge + TypeTag; ContactActions; note in a FormGroup *Note from China*; ActionBar with next-step primary + secondary; destructive *Delete* |

## Using this in the app (React + Vite + Tailwind)

Copy `tokens.css` (generated from `tokens.json`) into `src/styles/tokens.css`, import it once, and point Tailwind at the variables so classes and tokens never drift:

```js
// tailwind.config.js
export default {
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        grouped: 'var(--bg-grouped)', surface: 'var(--surface)', 'surface-2': 'var(--surface-2)',
        separator: 'var(--separator)', label: 'var(--label)', 'label-2': 'var(--label-secondary)', 'label-3': 'var(--label-tertiary)',
        accent: { DEFAULT: 'var(--accent)', pressed: 'var(--accent-pressed)', ink: 'var(--accent-ink)', soft: 'var(--accent-soft)' },
        pending: { DEFAULT: 'var(--pending)', soft: 'var(--pending-soft)', ink: 'var(--pending-ink)' },
        arrived: { DEFAULT: 'var(--arrived)', soft: 'var(--arrived-soft)', ink: 'var(--arrived-ink)' },
        delivered: { DEFAULT: 'var(--delivered)', soft: 'var(--delivered-soft)', ink: 'var(--delivered-ink)' },
        danger: { DEFAULT: 'var(--danger)', ink: 'var(--danger-ink)' },
      },
      borderRadius: { sm: 'var(--radius-sm)', md: 'var(--radius-md)', lg: 'var(--radius-lg)' },
      fontFamily: { sans: 'var(--font-sans)' },
      maxWidth: { app: 'var(--layout-max)' },
    },
  },
};
```

So a card is `bg-surface rounded-md px-4 py-3`, the page is `bg-grouped min-h-dvh`, a pending badge is `bg-pending-soft text-pending-ink`. The component guidelines in this system give the exact anatomy of each piece.

## PWA details that affect the UI

- App icons are ready in the **App icons** group: `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` (glyph inside the 80% safe zone), `apple-touch-icon.png` (180px, full-bleed — iOS rounds it), `favicon-32.png`, plus `icon-any.svg` / `icon-maskable.svg` sources. Manifest and meta tags: see *Theme*.
- `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">` so the ActionBar can pad for the home indicator.
- Photo inputs use `accept="image/*"` without `capture`, so both camera and gallery are offered.

## Accessibility

- Text pairs meet 4.5:1 in both themes, except two kept from the brief and flagged: white on `accent` (4.0:1 light, 3.7:1 dark — button labels stay 17px semibold) and `label-tertiary` placeholders (3.3:1 — never the only label).
- Status is never colour-only: word + dot.
- Every control ≥ 44px; focus ring 3px `accent`.
