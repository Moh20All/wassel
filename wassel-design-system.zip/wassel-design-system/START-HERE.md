# Wassel design system — package

Read `README.md` (brand book, screens → components, Tailwind usage), then `Theme.md`.

- `tokens.json` — source of truth · `tokens.css` — CSS variables (light default, `[data-theme="dark"]`)
- `components/` — reference components (`bundle.js` + `bundle.css`, React 18 via `window.React`), props in `index.d.ts`, guidelines + live previews per folder
- `assets/Logos`, `assets/App icons`, `assets/Icons` — SVG/PNG
- `starter/` — drop-in files for the React + Vite app:
  - `tailwind.config.js`
  - `theme.ts` → `src/theme.ts`
  - `index-head.html` → paste into `index.html` `<head>`
  - `public/manifest.webmanifest`, `public/icons/*.png` → `public/`
  - copy `tokens.css` → `src/styles/tokens.css` and import it in `main.tsx`
