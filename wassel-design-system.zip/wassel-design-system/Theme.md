# Theme

Two themes, one set of token names. **Light is the default** (`data-theme="light"`); dark uses iOS dark system colours. Components never hard-code a colour — they read `var(--token)`, so switching theme is one attribute on `<html>`.

## Light and dark at a glance

| Role | Token | Light | Dark |
| --- | --- | --- | --- |
| Page | `bg-grouped` | #f2f2f7 | #000000 |
| Cards, groups | `surface` | #ffffff | #1c1c1e |
| Fills, tracks | `surface-2` | #f2f2f7 | #2c2c2e |
| Text | `label` | #000000 | #ffffff |
| Secondary text | `label-secondary` | #6c6c70 | #aeaeb2 |
| Accent | `accent` | #007aff | #0a84ff |
| Pending | `pending` / `pending-ink` | #ff9500 / #b34700 | #ff9f0a / #ffb340 |
| Arrived | `arrived` / `arrived-ink` | #007aff / #0058b8 | #0a84ff / #64b0ff |
| Delivered | `delivered` / `delivered-ink` | #34c759 / #1a7431 | #30d158 / #4cd964 |

## Switching

Follow the phone by default, allow an override later if wanted:

```ts
// src/theme.ts — call once before React renders
const mq = window.matchMedia('(prefers-color-scheme: dark)');
export function applyTheme(pref: 'system' | 'light' | 'dark' = (localStorage.getItem('theme') as any) || 'system') {
  const dark = pref === 'dark' || (pref === 'system' && mq.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#000000' : '#f2f2f7');
}
mq.addEventListener('change', () => applyTheme());
```

Tailwind: `darkMode: ['class', '[data-theme="dark"]']` (already in the README config) — but prefer the token colours (`bg-surface`, `text-label`), which switch on their own; `dark:` variants should almost never be needed.

## index.html head

```html
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f2f2f7" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Wassel">
<link rel="icon" href="/icons/favicon-32.png" sizes="32x32">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
```

## manifest.webmanifest

```json
{
  "name": "Wassel",
  "short_name": "Wassel",
  "start_url": "/",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#f2f2f7",
  "theme_color": "#f2f2f7",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

## Rules

- Depth is gray page vs `surface` card in both themes; in dark there are no shadows (`shadow-segment` is `none`).
- Status badges always use the `*-soft` fill + `*-ink` text pair of the current theme; the saturated hue is only the dot.
- Photos are shown as-is in both themes — no dimming.
- The app icon doesn't change with the theme.
