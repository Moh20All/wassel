# App icons

PWA and home-screen icons, ready to copy into `public/icons/`. `icon-192/512.png` = purpose `any` (rounded square, transparent corners); `icon-maskable-512.png` = full-bleed blue with the glyph inside the 80% safe zone for Android adaptive icons; `apple-touch-icon.png` = 180px full-bleed (iOS applies its own mask); `favicon-32.png` for the browser tab. SVG sources included.
