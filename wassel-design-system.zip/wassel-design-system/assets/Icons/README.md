# Icons

UI icon set: 24px grid, 2px stroke, round caps and joins, single ink (black). Display at 20px in buttons and rows, 12px in tags. For other colours, inline the SVG and swap the stroke to `currentColor`, or use the file as a CSS `mask-image`. `papers` and `parts` are the shipment-type glyphs; `inbound` echoes the logo glyph. Equivalent lucide-react names: ChevronLeft/Right, Camera, Phone, MessageSquare, Check, X, Plus, Trash2, LogOut, FileText, Package, ArrowDownToLine.
