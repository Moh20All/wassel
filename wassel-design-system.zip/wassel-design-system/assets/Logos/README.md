# Logos

Wassel mark (the app icon), wordmark and lockup. All are outlined SVG — no font needed. Use the plain files on light grounds (`bg-grouped`, `surface`) and the `-white` files on dark grounds. The mark keeps its blue square and orange dot on every ground. Minimum size: mark 24px, lockup 96px wide.
