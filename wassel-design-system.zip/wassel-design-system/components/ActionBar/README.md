# ActionBar

Sticky bottom bar holding the screen's buttons, above the home indicator.

- `position: sticky; bottom: 0` at the end of the screen; pads for `env(safe-area-inset-bottom)` (needs `viewport-fit=cover`).
- Detail: primary = next status step, secondary = the other. When delivered, show a quiet line instead: “Auto-deletes on 21 Nov” and a destructive *Delete now*.
- China form: one primary *Submit shipment*.
