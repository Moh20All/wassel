# Button

The one button: primary for the screen's single main action, secondary for the alternative, plain for text actions, destructive for delete.

- **One primary per screen**: *Submit* (China), *Sign in*, and on detail the next status step (*Mark arrived* when pending, *Mark delivered* when arrived).
- **secondary** (`accent-soft` fill) for the step after the next one, so both detail actions stay visible but the right one leads.
- **destructive** is text-only (`danger-ink` on `surface`); always confirm with a sheet before deleting.
- `loading` while Firestore/Storage writes run: the button disables itself so Submit is never sent twice.
- Height `button-h` (50px), radius `radius-md`, label = headline style. Full-width (`block`) inside the bottom ActionBar.
- Contrast: white on `accent` is 4.0:1 (#007AFF as specified). Keep labels 17px semibold; don't shrink them.
