# ContactActions

Detail-screen contact block: the tappable phone number plus Call and WhatsApp buttons.

- Number as typed, in `accent-ink`, `tel:` link.
- WhatsApp opens `https://wa.me/<digits>`; a leading `0` becomes `213` (Algeria). Use `Wassel.toWhatsAppUrl(phone)`.
- WhatsApp uses the green `delivered-soft` / `delivered-ink` pair with a generic chat glyph — not the WhatsApp logo.
