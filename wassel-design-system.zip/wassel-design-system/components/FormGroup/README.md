# FormGroup

An iOS inset-grouped block: uppercase header, white rounded group of rows with hairline separators, optional help or error line.

- Groups sit on `bg-grouped` with `space-5` between them, `radius-md` corners, `separator` hairlines inset by `space-4`.
- Header: footnote style, uppercase, `label-secondary`.
- Login screen = one group (Email, Password) + primary *Sign in*. China form = groups *Client*, *Shipment* (type segmented control), *Photos*, *Note*.
