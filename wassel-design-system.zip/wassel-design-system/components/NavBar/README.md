# NavBar

Top bar for every screen: large title on the list and China form, inline title with Back on the detail screen.

- List and China form: `large` title (34px bold), trailing plain **Log out**.
- Detail: inline 17px title, leading Back labelled with the previous screen (`Shipments`).
- Background is `bg-grouped`, never white: the bar blends with the page. When content scrolls under it, the app may add `backdrop-filter: blur(20px)` over a translucent `surface`.
- The consumer provides the routing (`onBack`).
