# PhotoPicker

Three square photo slots for the China form: add from camera/gallery, remove with the red ×.

- 1–3 photos; the add slot disappears at 3. Submit stays disabled until there is at least one.
- The add slot wraps a hidden `<input type="file" accept="image/*" multiple>` (no `capture` attribute, so both camera and gallery are offered).
- Compress before upload (max 1600px long edge, JPEG ~0.8) — China may be on slow mobile data.
- Remove button: 24px `danger` disc with a `surface` ring, offset outside the corner.
