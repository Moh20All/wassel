# SegmentedControl

iOS segmented control: the list filter (All / Pending / Arrived / Done) and the Papers/Parts choice in the China form.

- Filter options map to Firestore `status`: All, Pending → `pending`, Arrived → `arrived`, Done → `delivered`.
- Counts are optional; show them on the list filter so Moha sees how many are waiting.
- The type choice in the China form defaults to **Papers**, so a shipment can never be submitted without a type.
- Track `surface-2`, thumb `surface-raised` + `shadow-segment`, 32px tall inside a 36px track.
