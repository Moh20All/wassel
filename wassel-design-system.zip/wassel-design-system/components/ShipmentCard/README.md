# ShipmentCard

One shipment in the agency list: thumbnail, client name, time logged, status badge, type tag; tap opens detail.

- Cards stack with `space-2` gaps on `bg-grouped`, side gutter `space-4`, sorted `createdAt` desc.
- Thumbnail = first of `photos` (56px, `radius-sm`); no photo → type glyph.
- Time: relative under 24h (`12 min ago`), then `Yesterday`, then `3 Nov`.
- Long names truncate with an ellipsis; the time never wraps.
- The whole card is the button (min 80px tall), with a chevron as the affordance.
