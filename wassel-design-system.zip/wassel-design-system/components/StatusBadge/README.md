# StatusBadge

Pill showing a shipment's status: Pending (orange), Arrived (blue), Delivered (green).

- Colour is never alone: each badge has its word and a dot. Text uses the `*-ink` tokens (≥5:1 on their `*-soft` fill); the saturated hue is only the dot.
- Orange/blue/green differ in lightness as well as hue, so the three stay distinct for colour-blind users.
- Caption style (12px semibold). Don't resize.
