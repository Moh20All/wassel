# TextField

One labelled input row inside a FormGroup: client name, phone, note, email, password.

- The label is always visible above the value; the placeholder is only an example (`label-tertiary` is 3.3:1, too faint to carry meaning).
- Phone: `type="tel"` `inputMode="tel"`, keep what China types; normalize only when building links.
- Inputs are 17px so iOS Safari doesn't zoom on focus.
- `error` turns the label `danger-ink`; put the message in the FormGroup's `error`.
