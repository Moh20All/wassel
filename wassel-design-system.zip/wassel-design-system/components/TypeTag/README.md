# TypeTag

Neutral pill for the shipment type, Papers or Parts, with a small glyph.

- Always gray (`surface-2` / `label-secondary`) so it never competes with the status badge.
- Sits right after the StatusBadge on a card.
