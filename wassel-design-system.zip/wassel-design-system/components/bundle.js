/* @ds-bundle: {"format":4,"namespace":"Wassel","components":[{"name":"NavBar"},{"name":"Button"},{"name":"TextField"},{"name":"FormGroup"},{"name":"SegmentedControl"},{"name":"StatusBadge"},{"name":"TypeTag"},{"name":"ShipmentCard"},{"name":"PhotoPicker"},{"name":"ContactActions"},{"name":"ActionBar"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(" "); }

  function Icon(props) {
    var d = {
      chevronRight: "M9 6l6 6-6 6",
      chevronLeft: "M15 6l-6 6 6 6",
      camera: "M4 8h3l2-3h6l2 3h3v11H4z M12 17a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
      phone: "M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1z",
      chat: "M4 5h16v11H9l-5 4z",
      doc: "M7 3h7l4 4v14H7z M14 3v4h4",
      box: "M4 7l8-4 8 4v10l-8 4-8-4z M4 7l8 4 8-4 M12 11v10",
      x: "M7 7l10 10M17 7L7 17",
      plus: "M12 5v14M5 12h14"
    }[props.name];
    var s = props.size || 20;
    return h("svg", { width: s, height: s, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: props.weight || 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true" }, h("path", { d: d }));
  }

  function NavBar(p) {
    return h("header", { className: "ib-nav" },
      h("div", { className: "ib-nav-bar" },
        h("div", { className: "ib-nav-slot" }, p.onBack ? h("button", { className: "ib-btn ib-btn-plain ib-back", onClick: p.onBack }, h(Icon, { name: "chevronLeft", size: 22, weight: 2.5 }), p.backLabel || "Back") : p.leading || null),
        p.large ? null : h("div", { className: "ib-nav-title" }, p.title),
        h("div", { className: "ib-nav-slot" }, p.trailing || null)),
      p.large ? h("h1", { className: "ib-nav-large" }, p.title) : null);
  }

  function Button(p) {
    var variant = p.variant || "primary";
    return h("button", {
      type: p.type || "button", disabled: p.disabled || p.loading, onClick: p.onClick,
      className: cx("ib-btn", "ib-btn-" + variant, p.block && "ib-btn-block", p.className)
    }, p.loading ? h("span", { className: "ib-spinner", "aria-label": "Loading" }) : null, p.children);
  }

  function TextField(p) {
    var id = p.id || ("f-" + String(p.label).replace(/\W+/g, "-").toLowerCase());
    var input = p.multiline
      ? h("textarea", { id: id, rows: p.rows || 3, placeholder: p.placeholder, value: p.value, defaultValue: p.defaultValue, onChange: p.onChange })
      : h("input", { id: id, type: p.type || "text", inputMode: p.inputMode, autoComplete: p.autoComplete, placeholder: p.placeholder, value: p.value, defaultValue: p.defaultValue, onChange: p.onChange });
    return h("div", { className: cx("ib-field", p.error && "ib-field-error") },
      h("label", { className: "ib-field-label", htmlFor: id }, p.label, p.optional ? " (optional)" : ""),
      input);
  }

  function FormGroup(p) {
    return h("section", null,
      p.label ? h("h3", { className: "ib-group-label" }, p.label) : null,
      h("div", { className: "ib-group" }, p.children),
      p.error ? h("p", { className: "ib-help ib-help-error", role: "alert" }, p.error) : p.help ? h("p", { className: "ib-help" }, p.help) : null);
  }

  function SegmentedControl(p) {
    return h("div", { className: "ib-seg", role: "group", "aria-label": p.label || "Filter" },
      p.options.map(function (o) {
        return h("button", { key: o.value, "aria-pressed": o.value === p.value, onClick: function () { p.onChange && p.onChange(o.value); } },
          o.label, o.count != null ? h("span", { className: "ib-seg-count" }, o.count) : null);
      }));
  }

  var STATUS = { pending: "Pending", arrived: "Arrived", delivered: "Delivered" };
  function StatusBadge(p) {
    return h("span", { className: "ib-badge ib-badge-" + p.status }, STATUS[p.status]);
  }

  function TypeTag(p) {
    return h("span", { className: "ib-tag" }, h(Icon, { name: p.type === "parts" ? "box" : "doc", size: 12, weight: 2.4 }), p.type === "parts" ? "Parts" : "Papers");
  }

  function ShipmentCard(p) {
    return h("button", { className: "ib-card", onClick: p.onClick },
      p.photo ? h("img", { className: "ib-thumb", src: p.photo, alt: "" }) : h("span", { className: "ib-thumb" }, h(Icon, { name: p.type === "parts" ? "box" : "doc", size: 24, weight: 1.6 })),
      h("span", { className: "ib-card-body" },
        h("span", { className: "ib-card-top" },
          h("span", { className: "ib-card-name" }, p.clientName),
          h("span", { className: "ib-card-time" }, p.time)),
        h("span", { className: "ib-card-meta" }, h(StatusBadge, { status: p.status }), h(TypeTag, { type: p.type }))),
      h("span", { className: "ib-chev" }, h(Icon, { name: "chevronRight", size: 18, weight: 2.5 })));
  }

  function PhotoPicker(p) {
    var max = p.max || 3, photos = p.photos || [], slots = [];
    photos.forEach(function (src, i) {
      slots.push(h("div", { className: "ib-slot", key: "p" + i },
        h("img", { src: src, alt: "Photo " + (i + 1) }),
        h("button", { className: "ib-slot-remove", "aria-label": "Remove photo " + (i + 1), onClick: function () { p.onRemove && p.onRemove(i); } }, h(Icon, { name: "x", size: 14, weight: 3 }))));
    });
    if (photos.length < max) {
      slots.push(h("button", { className: "ib-slot ib-slot-add", key: "add", onClick: p.onAdd }, h(Icon, { name: "camera", size: 26, weight: 1.8 }), photos.length ? "Add" : "Add photo"));
    }
    return h("div", { className: "ib-photos" }, slots);
  }

  function toWa(phone) {
    var d = String(phone).replace(/\D/g, "");
    if (d.charAt(0) === "0") d = "213" + d.slice(1);
    return "https://wa.me/" + d;
  }
  function ContactActions(p) {
    var tel = String(p.phone).replace(/\s/g, "");
    return h("div", null,
      h("a", { className: "ib-phone", href: "tel:" + tel }, p.phone),
      h("div", { className: "ib-contact" },
        h("a", { className: "ib-contact-call", href: "tel:" + tel }, h(Icon, { name: "phone" }), "Call"),
        h("a", { className: "ib-contact-wa", href: toWa(p.phone), target: "_blank", rel: "noopener" }, h(Icon, { name: "chat" }), "WhatsApp")));
  }

  function ActionBar(p) { return h("div", { className: "ib-actionbar" }, p.children); }

  window.Wassel = Object.assign(window.Wassel || {}, {
    NavBar: NavBar, Button: Button, TextField: TextField, FormGroup: FormGroup, SegmentedControl: SegmentedControl,
    StatusBadge: StatusBadge, TypeTag: TypeTag, ShipmentCard: ShipmentCard, PhotoPicker: PhotoPicker,
    ContactActions: ContactActions, ActionBar: ActionBar, Icon: Icon, toWhatsAppUrl: toWa
  });
})();
