// Wassel — component props (documentation; window.Wassel.*)
export type ShipmentStatus = "pending" | "arrived" | "delivered";
export type ShipmentType = "papers" | "parts";

export interface NavBarProps {
  title: string;
  /** Large 34px title under the bar (list + China form). Detail screen uses the inline title. */
  large?: boolean;
  onBack?: () => void;
  backLabel?: string;
  leading?: React.ReactNode;
  /** e.g. a plain "Log out" button */
  trailing?: React.ReactNode;
}

export interface ButtonProps {
  variant?: "primary" | "secondary" | "plain" | "destructive";
  block?: boolean;
  loading?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
  onClick?: () => void;
  children: React.ReactNode;
}

export interface TextFieldProps {
  label: string;
  type?: "text" | "tel" | "email" | "password";
  inputMode?: "text" | "tel" | "email";
  autoComplete?: string;
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  multiline?: boolean;
  rows?: number;
  optional?: boolean;
  error?: boolean;
}

export interface FormGroupProps {
  label?: string;
  help?: string;
  error?: string;
  children: React.ReactNode;
}

export interface SegmentedControlProps {
  options: { value: string; label: string; count?: number }[];
  value: string;
  onChange?: (value: string) => void;
  label?: string;
}

export interface StatusBadgeProps { status: ShipmentStatus }
export interface TypeTagProps { type: ShipmentType }

export interface ShipmentCardProps {
  clientName: string;
  type: ShipmentType;
  status: ShipmentStatus;
  /** Relative time logged: "2h ago", "Yesterday", "12 Nov" */
  time: string;
  /** First photo URL; falls back to a type icon */
  photo?: string;
  onClick?: () => void;
}

export interface PhotoPickerProps {
  photos: string[];
  /** default 3 */
  max?: number;
  onAdd?: () => void;
  onRemove?: (index: number) => void;
}

export interface ContactActionsProps {
  /** As typed by China, e.g. "0555 12 34 56"; WhatsApp link converts leading 0 to 213 */
  phone: string;
}

export interface ActionBarProps { children: React.ReactNode }
