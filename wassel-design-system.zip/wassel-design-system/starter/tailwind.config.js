// tailwind.config.js
export default {
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        grouped: 'var(--bg-grouped)', surface: 'var(--surface)', 'surface-2': 'var(--surface-2)',
        separator: 'var(--separator)', label: 'var(--label)', 'label-2': 'var(--label-secondary)', 'label-3': 'var(--label-tertiary)',
        accent: { DEFAULT: 'var(--accent)', pressed: 'var(--accent-pressed)', ink: 'var(--accent-ink)', soft: 'var(--accent-soft)' },
        pending: { DEFAULT: 'var(--pending)', soft: 'var(--pending-soft)', ink: 'var(--pending-ink)' },
        arrived: { DEFAULT: 'var(--arrived)', soft: 'var(--arrived-soft)', ink: 'var(--arrived-ink)' },
        delivered: { DEFAULT: 'var(--delivered)', soft: 'var(--delivered-soft)', ink: 'var(--delivered-ink)' },
        danger: { DEFAULT: 'var(--danger)', ink: 'var(--danger-ink)' },
      },
      borderRadius: { sm: 'var(--radius-sm)', md: 'var(--radius-md)', lg: 'var(--radius-lg)' },
      fontFamily: { sans: 'var(--font-sans)' },
      maxWidth: { app: 'var(--layout-max)' },
    },
  },
};
